                                               Table "public.alembic_version"
   Column    |         Type          | Collation | Nullable | Default | Storage  | Compression | Stats target | Description 
-------------+-----------------------+-----------+----------+---------+----------+-------------+--------------+-------------
 version_num | character varying(32) |           | not null |         | extended |             |              | 
Indexes:
    "alembic_version_pkc" PRIMARY KEY, btree (version_num)
Access method: heap

                                                                   Table "public.comment"
   Column   |            Type             | Collation | Nullable |               Default               | Storage  | Compression | Stats target | Description 
------------+-----------------------------+-----------+----------+-------------------------------------+----------+-------------+--------------+-------------
 id         | integer                     |           | not null | nextval('comment_id_seq'::regclass) | plain    |             |              | 
 content    | text                        |           | not null |                                     | extended |             |              | 
 user_id    | integer                     |           | not null |                                     | plain    |             |              | 
 dream_id   | integer                     |           | not null |                                     | plain    |             |              | 
 created_at | timestamp without time zone |           |          |                                     | plain    |             |              | 
Indexes:
    "comment_pkey" PRIMARY KEY, btree (id)
Foreign-key constraints:
    "comment_dream_id_fkey" FOREIGN KEY (dream_id) REFERENCES dream(id)
    "comment_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
Access method: heap

                                                                        Table "public.dream"
       Column        |            Type             | Collation | Nullable |              Default              | Storage  | Compression | Stats target | Description 
---------------------+-----------------------------+-----------+----------+-----------------------------------+----------+-------------+--------------+-------------
 id                  | integer                     |           | not null | nextval('dream_id_seq'::regclass) | plain    |             |              | 
 user_id             | integer                     |           | not null |                                   | plain    |             |              | 
 title               | character varying(100)      |           | not null |                                   | extended |             |              | 
 content             | text                        |           | not null |                                   | extended |             |              | 
 created_at          | timestamp without time zone |           |          |                                   | plain    |             |              | 
 date                | timestamp without time zone |           |          |                                   | plain    |             |              | 
 mood                | character varying(50)       |           |          |                                   | extended |             |              | 
 sentiment_score     | double precision            |           |          |                                   | plain    |             |              | 
 sentiment_magnitude | double precision            |           |          |                                   | plain    |             |              | 
 dominant_emotions   | character varying(200)      |           |          |                                   | extended |             |              | 
 lucidity_level      | integer                     |           |          |                                   | plain    |             |              | 
 tags                | character varying(200)      |           |          |                                   | extended |             |              | 
 is_public           | boolean                     |           |          |                                   | plain    |             |              | 
 is_anonymous        | boolean                     |           |          |                                   | plain    |             |              | 
 ai_analysis         | text                        |           |          |                                   | extended |             |              | 
 sleep_duration      | double precision            |           |          |                                   | plain    |             |              | 
 sleep_quality       | integer                     |           |          |                                   | plain    |             |              | 
 bed_time            | timestamp without time zone |           |          |                                   | plain    |             |              | 
 wake_time           | timestamp without time zone |           |          |                                   | plain    |             |              | 
 sleep_interruptions | integer                     |           |          |                                   | plain    |             |              | 
 sleep_position      | character varying(50)       |           |          |                                   | extended |             |              | 
Indexes:
    "dream_pkey" PRIMARY KEY, btree (id)
Foreign-key constraints:
    "dream_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
Referenced by:
    TABLE "comment" CONSTRAINT "comment_dream_id_fkey" FOREIGN KEY (dream_id) REFERENCES dream(id)
Access method: heap

                                                                    Table "public.dream_group"
   Column    |            Type             | Collation | Nullable |                 Default                 | Storage  | Compression | Stats target | Description 
-------------+-----------------------------+-----------+----------+-----------------------------------------+----------+-------------+--------------+-------------
 id          | integer                     |           | not null | nextval('dream_group_id_seq'::regclass) | plain    |             |              | 
 name        | character varying(100)      |           | not null |                                         | extended |             |              | 
 description | text                        |           |          |                                         | extended |             |              | 
 created_by  | integer                     |           | not null |                                         | plain    |             |              | 
 created_at  | timestamp without time zone |           |          |                                         | plain    |             |              | 
Indexes:
    "dream_group_pkey" PRIMARY KEY, btree (id)
Foreign-key constraints:
    "dream_group_created_by_fkey" FOREIGN KEY (created_by) REFERENCES "user"(id)
Referenced by:
    TABLE "forum_post" CONSTRAINT "forum_post_group_id_fkey" FOREIGN KEY (group_id) REFERENCES dream_group(id)
    TABLE "group_membership" CONSTRAINT "group_membership_group_id_fkey" FOREIGN KEY (group_id) REFERENCES dream_group(id)
Access method: heap

                                                                   Table "public.forum_post"
   Column   |            Type             | Collation | Nullable |                Default                 | Storage  | Compression | Stats target | Description 
------------+-----------------------------+-----------+----------+----------------------------------------+----------+-------------+--------------+-------------
 id         | integer                     |           | not null | nextval('forum_post_id_seq'::regclass) | plain    |             |              | 
 title      | character varying(200)      |           | not null |                                        | extended |             |              | 
 content    | text                        |           | not null |                                        | extended |             |              | 
 user_id    | integer                     |           | not null |                                        | plain    |             |              | 
 group_id   | integer                     |           | not null |                                        | plain    |             |              | 
 created_at | timestamp without time zone |           |          |                                        | plain    |             |              | 
Indexes:
    "forum_post_pkey" PRIMARY KEY, btree (id)
Foreign-key constraints:
    "forum_post_group_id_fkey" FOREIGN KEY (group_id) REFERENCES dream_group(id)
    "forum_post_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
Referenced by:
    TABLE "forum_reply" CONSTRAINT "forum_reply_post_id_fkey" FOREIGN KEY (post_id) REFERENCES forum_post(id)
Access method: heap

                                                                   Table "public.forum_reply"
   Column   |            Type             | Collation | Nullable |                 Default                 | Storage  | Compression | Stats target | Description 
------------+-----------------------------+-----------+----------+-----------------------------------------+----------+-------------+--------------+-------------
 id         | integer                     |           | not null | nextval('forum_reply_id_seq'::regclass) | plain    |             |              | 
 content    | text                        |           | not null |                                         | extended |             |              | 
 user_id    | integer                     |           | not null |                                         | plain    |             |              | 
 post_id    | integer                     |           | not null |                                         | plain    |             |              | 
 created_at | timestamp without time zone |           |          |                                         | plain    |             |              | 
Indexes:
    "forum_reply_pkey" PRIMARY KEY, btree (id)
Foreign-key constraints:
    "forum_reply_post_id_fkey" FOREIGN KEY (post_id) REFERENCES forum_post(id)
    "forum_reply_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
Access method: heap

                                                Table "public.group_membership"
  Column   |            Type             | Collation | Nullable | Default | Storage | Compression | Stats target | Description 
-----------+-----------------------------+-----------+----------+---------+---------+-------------+--------------+-------------
 user_id   | integer                     |           | not null |         | plain   |             |              | 
 group_id  | integer                     |           | not null |         | plain   |             |              | 
 is_admin  | boolean                     |           |          |         | plain   |             |              | 
 joined_at | timestamp without time zone |           |          |         | plain   |             |              | 
Indexes:
    "group_membership_pkey" PRIMARY KEY, btree (user_id, group_id)
Foreign-key constraints:
    "group_membership_group_id_fkey" FOREIGN KEY (group_id) REFERENCES dream_group(id)
    "group_membership_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
Access method: heap

                                                                           Table "public.user"
          Column           |            Type             | Collation | Nullable |             Default              | Storage  | Compression | Stats target | Description 
---------------------------+-----------------------------+-----------+----------+----------------------------------+----------+-------------+--------------+-------------
 id                        | integer                     |           | not null | nextval('user_id_seq'::regclass) | plain    |             |              | 
 username                  | character varying(64)       |           | not null |                                  | extended |             |              | 
 email                     | character varying(120)      |           | not null |                                  | extended |             |              | 
 password_hash             | character varying(256)      |           |          |                                  | extended |             |              | 
 subscription_type         | character varying(20)       |           |          |                                  | extended |             |              | 
 subscription_end_date     | timestamp without time zone |           |          |                                  | plain    |             |              | 
 monthly_ai_analysis_count | integer                     |           |          |                                  | plain    |             |              | 
 last_analysis_reset       | timestamp without time zone |           |          |                                  | plain    |             |              | 
Indexes:
    "user_pkey" PRIMARY KEY, btree (id)
    "user_email_key" UNIQUE CONSTRAINT, btree (email)
    "user_username_key" UNIQUE CONSTRAINT, btree (username)
Referenced by:
    TABLE "comment" CONSTRAINT "comment_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
    TABLE "dream_group" CONSTRAINT "dream_group_created_by_fkey" FOREIGN KEY (created_by) REFERENCES "user"(id)
    TABLE "dream" CONSTRAINT "dream_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
    TABLE "forum_post" CONSTRAINT "forum_post_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
    TABLE "forum_reply" CONSTRAINT "forum_reply_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
    TABLE "group_membership" CONSTRAINT "group_membership_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
    TABLE "user_activity" CONSTRAINT "user_activity_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
Access method: heap

                                                                     Table "public.user_activity"
    Column     |            Type             | Collation | Nullable |                  Default                  | Storage  | Compression | Stats target | Description 
---------------+-----------------------------+-----------+----------+-------------------------------------------+----------+-------------+--------------+-------------
 id            | integer                     |           | not null | nextval('user_activity_id_seq'::regclass) | plain    |             |              | 
 user_id       | integer                     |           | not null |                                           | plain    |             |              | 
 activity_type | character varying(50)       |           | not null |                                           | extended |             |              | 
 description   | text                        |           |          |                                           | extended |             |              | 
 target_type   | character varying(50)       |           |          |                                           | extended |             |              | 
 target_id     | integer                     |           |          |                                           | plain    |             |              | 
 created_at    | timestamp without time zone |           |          |                                           | plain    |             |              | 
 ip_address    | character varying(45)       |           |          |                                           | extended |             |              | 
 user_agent    | character varying(256)      |           |          |                                           | extended |             |              | 
Indexes:
    "user_activity_pkey" PRIMARY KEY, btree (id)
Foreign-key constraints:
    "user_activity_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id)
Access method: heap

